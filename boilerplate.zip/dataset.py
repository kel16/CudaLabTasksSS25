class CustomDataset:
    """
    """
    
    def __init__(self):
        """ """ 
        return

    def __len__(self):
        """ """
        return len(0)
    
    def __getitem__(self, i):
        """ """
        return
    